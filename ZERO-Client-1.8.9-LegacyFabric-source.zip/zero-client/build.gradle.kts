plugins {
    id("fabric-loom") version "1.9-SNAPSHOT"
    id("legacy-looming") version "1.9-SNAPSHOT"
}

group = project.property("maven_group") as String
version = project.property("mod_version") as String
base {
    archivesName.set(project.property("archives_base_name") as String)
}

repositories {
    maven("https://maven.legacyfabric.net/")
    maven("https://maven.fabricmc.net/")
}

legacyLooming {
    // Legacy Fabric intermediary generation 1 is the default for this target.
}

dependencies {
    minecraft("com.mojang:minecraft:${project.property("minecraft_version")}")
    mappings(legacy.yarn(
        project.property("minecraft_version") as String,
        project.property("yarn_build") as String
    ))
    modImplementation("net.fabricmc:fabric-loader:${project.property("loader_version")}")
    modImplementation("net.legacyfabric.legacy-fabric-api:legacy-fabric-api:${project.property("fabric_version")}")
}

tasks {
    processResources {
        val buildProperties = mapOf("version" to project.version)
        inputs.properties(buildProperties)
        filteringCharset = "UTF-8"
        filesMatching("fabric.mod.json") {
            expand(buildProperties)
        }
    }

    withType<JavaCompile> {
        options.encoding = "UTF-8"
        options.release = 8
    }

    java {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
        withSourcesJar()
    }
}
