package dev.zero.client.util;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.MappingResolver;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Reflection adapter around the 1.8.9 client objects. Keeping game access here
 * isolates mapping-name differences and keeps each module small.
 */
public final class GameAccess {
    private GameAccess() {
    }

    public static Object player(Object client) {
        return read(client, "player", "thePlayer", "field_71439_g");
    }

    public static Object world(Object client) {
        return read(client, "world", "theWorld", "field_71441_e");
    }

    public static boolean inGame(Object client) {
        return player(client) != null && world(client) != null;
    }

    public static List<Object> players(Object client) {
        Object world = world(client);
        if (world == null) {
            return Collections.emptyList();
        }
        Object source = read(world, "entities", "loadedEntityList", "entityList", "field_72996_f");
        if (!(source instanceof Iterable)) {
            source = call(world, new String[] {"getEntities", "getLoadedEntities"});
        }
        if (!(source instanceof Iterable)) {
            return Collections.emptyList();
        }
        List<Object> result = new ArrayList<Object>();
        Object self = player(client);
        for (Object entity : (Iterable<?>) source) {
            if (entity == null || entity == self || !isPlayerEntity(entity)) {
                continue;
            }
            result.add(entity);
        }
        return result;
    }

    public static boolean isPlayerEntity(Object entity) {
        String name = entity.getClass().getName();
        try {
            name = resolver().unmapClassName("named", name);
        } catch (Throwable ignored) {
        }
        name = name.toLowerCase();
        return name.contains("playerentity") || name.contains("entityplayer") ||
                entity.getClass().getSimpleName().toLowerCase().contains("player");
    }

    public static Object nearestPlayer(Object client, double range) {
        Object self = player(client);
        if (self == null) {
            return null;
        }
        Object best = null;
        double bestDistance = range;
        for (Object candidate : players(client)) {
            double distance = distance(self, candidate);
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = candidate;
            }
        }
        return best;
    }

    public static Object playerInView(Object client, double range, double maxAngle) {
        Object self = player(client);
        if (self == null) {
            return null;
        }
        Object best = null;
        double bestAngle = maxAngle;
        for (Object candidate : players(client)) {
            if (distance(self, candidate) > range) {
                continue;
            }
            double angle = angleTo(self, candidate);
            if (angle <= bestAngle) {
                bestAngle = angle;
                best = candidate;
            }
        }
        return best;
    }

    public static double distance(Object a, Object b) {
        double dx = x(a) - x(b);
        double dy = y(a) - y(b);
        double dz = z(a) - z(b);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static double x(Object entity) {
        return number(entity, 0.0D, new String[] {"x", "posX", "field_70165_t"}, new String[] {"getX", "getPosX"});
    }

    public static double y(Object entity) {
        return number(entity, 0.0D, new String[] {"y", "posY", "field_70163_u"}, new String[] {"getY", "getPosY"});
    }

    public static double z(Object entity) {
        return number(entity, 0.0D, new String[] {"z", "posZ", "field_70161_v"}, new String[] {"getZ", "getPosZ"});
    }

    public static float yaw(Object entity) {
        return (float) number(entity, 0.0D, new String[] {"yaw", "rotationYaw", "field_70177_z"}, new String[] {"getYaw"});
    }

    public static float pitch(Object entity) {
        return (float) number(entity, 0.0D, new String[] {"pitch", "rotationPitch", "field_70125_A"}, new String[] {"getPitch"});
    }

    public static void setYaw(Object entity, float value) {
        write(entity, Float.valueOf(value), "yaw", "rotationYaw", "field_70177_z");
    }

    public static void setPitch(Object entity, float value) {
        write(entity, Float.valueOf(value), "pitch", "rotationPitch", "field_70125_A");
    }

    public static void aimAt(Object client, Object target, float smoothing) {
        Object self = player(client);
        if (self == null || target == null) {
            return;
        }
        double dx = x(target) - x(self);
        double dz = z(target) - z(self);
        double dy = (y(target) + 1.0D) - (y(self) + eyeHeight(self));
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float wantedYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        float wantedPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        float factor = Math.max(0.02F, Math.min(1.0F, smoothing));
        setYaw(self, yaw(self) + wrapDegrees(wantedYaw - yaw(self)) * factor);
        setPitch(self, pitch(self) + wrapDegrees(wantedPitch - pitch(self)) * factor);
    }

    public static double angleTo(Object self, Object target) {
        double dx = x(target) - x(self);
        double dz = z(target) - z(self);
        double dy = (y(target) + 1.0D) - (y(self) + eyeHeight(self));
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float wantedYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        float wantedPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        double yawDifference = Math.abs(wrapDegrees(wantedYaw - yaw(self)));
        double pitchDifference = Math.abs(wrapDegrees(wantedPitch - pitch(self)));
        return Math.sqrt(yawDifference * yawDifference + pitchDifference * pitchDifference);
    }

    public static boolean attack(Object client, Object target) {
        Object self = player(client);
        if (self == null || target == null) {
            return false;
        }
        Object controller = read(client, "interactionManager", "playerController", "gameMode", "field_71442_b");
        boolean attacked = invoke(controller, new String[] {"attackEntity", "attack"}, self, target);
        invoke(self, new String[] {"swingItem", "swingHand"});
        return attacked;
    }

    public static void vanillaLeftClick(Object client) {
        if (!invoke(client, new String[] {"clickMouse", "doAttack"})) {
            Object controller = read(client, "interactionManager", "playerController", "gameMode");
            invoke(controller, new String[] {"attackEntity"}, player(client), crosshairEntity(client));
        }
    }

    public static void vanillaRightClick(Object client) {
        invoke(client, new String[] {"rightClickMouse", "doItemUse"});
    }

    public static Object crosshairEntity(Object client) {
        Object hit = read(client, "crosshairTarget", "objectMouseOver", "field_71476_x");
        return read(hit, "entity", "entityHit", "field_72308_g");
    }

    public static boolean leftMouseDown() {
        try {
            return Mouse.isButtonDown(0);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static int mouseScaledX(int scaledWidth) {
        try {
            return Mouse.getX() * scaledWidth / Math.max(1, org.lwjgl.opengl.Display.getWidth());
        } catch (Throwable ignored) {
            return -1;
        }
    }

    public static int mouseScaledY(int scaledHeight) {
        try {
            return scaledHeight - Mouse.getY() * scaledHeight / Math.max(1, org.lwjgl.opengl.Display.getHeight()) - 1;
        } catch (Throwable ignored) {
            return -1;
        }
    }

    public static boolean keyDown(int keyCode) {
        try {
            return Keyboard.isKeyDown(keyCode);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static boolean moving(Object player) {
        double forward = number(player, 0.0D, new String[] {"forwardSpeed", "moveForward"}, new String[] {"getForwardSpeed"});
        double strafe = number(player, 0.0D, new String[] {"sidewaysSpeed", "moveStrafing"}, new String[] {"getSidewaysSpeed"});
        if (Math.abs(forward) + Math.abs(strafe) > 0.01D) {
            return true;
        }
        double motionX = velocity(player, "x");
        double motionZ = velocity(player, "z");
        return Math.abs(motionX) + Math.abs(motionZ) > 0.04D;
    }

    public static boolean onGround(Object player) {
        return Boolean.TRUE.equals(read(player, "onGround", "field_70122_E"));
    }

    public static int hurtTime(Object player) {
        return (int) number(player, 0.0D, new String[] {"hurtTime", "hurtResistantTime", "field_70737_aN"}, new String[0]);
    }

    public static void setSprinting(Object player, boolean value) {
        invoke(player, new String[] {"setSprinting"}, Boolean.valueOf(value));
    }

    public static void scaleVelocity(Object player, double horizontal, double vertical) {
        scaleField(player, horizontal, "velocityX", "motionX", "field_70159_w");
        scaleField(player, vertical, "velocityY", "motionY", "field_70181_x");
        scaleField(player, horizontal, "velocityZ", "motionZ", "field_70179_y");
    }

    public static void setVerticalVelocity(Object player, double value) {
        writeNumber(player, value, "velocityY", "motionY", "field_70181_x");
    }

    public static void enableFlight(Object player) {
        Object abilities = read(player, "abilities", "capabilities", "field_71075_bZ");
        if (abilities == null) {
            return;
        }
        write(abilities, Boolean.TRUE, "allowFlying", "allowFlying", "field_75101_c");
        write(abilities, Boolean.TRUE, "flying", "isFlying", "field_75100_b");
        invoke(player, new String[] {"sendAbilitiesUpdate", "sendPlayerAbilities"});
    }

    public static String playerName(Object player) {
        Object name = call(player, new String[] {"getName", "getDisplayName"});
        if (name != null) {
            Object plain = call(name, new String[] {"getString", "getUnformattedText", "asString"});
            return plain == null ? String.valueOf(name) : String.valueOf(plain);
        }
        Object field = read(player, "name", "username");
        return field == null ? player.getClass().getSimpleName() : String.valueOf(field);
    }

    public static int scaledWidth(Object client) {
        Object resolution = scaledResolution(client);
        Object width = call(resolution, new String[] {"getScaledWidth"});
        return width instanceof Number ? ((Number) width).intValue() : 320;
    }

    public static int scaledHeight(Object client) {
        Object resolution = scaledResolution(client);
        Object height = call(resolution, new String[] {"getScaledHeight"});
        return height instanceof Number ? ((Number) height).intValue() : 240;
    }

    public static Object clientInstance() {
        String[] candidates = new String[] {
                mappedClassName("net.minecraft.client.MinecraftClient"),
                mappedClassName("net.minecraft.client.Minecraft"),
                "net.minecraft.client.MinecraftClient",
                "net.minecraft.client.Minecraft"
        };
        for (String candidate : candidates) {
            if (candidate == null) continue;
            try {
                Class<?> type = Class.forName(candidate);
                Object instance = callStatic(type, new String[] {"getInstance", "getMinecraft"});
                if (instance != null) return instance;
            } catch (Throwable ignored) {
            }
        }
        return null;
    }

    public static void drawRect(int left, int top, int right, int bottom, float red, float green, float blue, float alpha) {
        try {
            org.lwjgl.opengl.GL11.glDisable(org.lwjgl.opengl.GL11.GL_TEXTURE_2D);
            org.lwjgl.opengl.GL11.glColor4f(red, green, blue, alpha);
            org.lwjgl.opengl.GL11.glBegin(org.lwjgl.opengl.GL11.GL_QUADS);
            org.lwjgl.opengl.GL11.glVertex2f(left, bottom);
            org.lwjgl.opengl.GL11.glVertex2f(right, bottom);
            org.lwjgl.opengl.GL11.glVertex2f(right, top);
            org.lwjgl.opengl.GL11.glVertex2f(left, top);
            org.lwjgl.opengl.GL11.glEnd();
            org.lwjgl.opengl.GL11.glEnable(org.lwjgl.opengl.GL11.GL_TEXTURE_2D);
        } catch (Throwable ignored) {
        }
    }

    public static void drawText(Object client, String text, int x, int y, int color) {
        Object renderer = read(client, "textRenderer", "fontRenderer", "fontRendererObj", "field_71466_p");
        if (renderer == null) {
            return;
        }
        if (invoke(renderer, new String[] {"drawWithShadow", "drawStringWithShadow"}, text, Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(color))) {
            return;
        }
        invoke(renderer, new String[] {"draw", "drawString"}, text, Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(color));
    }

    private static Object scaledResolution(Object client) {
        String mapped = mappedClassName("net.minecraft.client.gui.ScaledResolution");
        String[] candidates = new String[] {mapped, "net.minecraft.client.gui.ScaledResolution"};
        for (String candidate : candidates) {
            if (candidate == null) continue;
            try {
                Class<?> type = Class.forName(candidate);
                for (java.lang.reflect.Constructor<?> constructor : type.getDeclaredConstructors()) {
                    Class<?>[] params = constructor.getParameterTypes();
                    if (params.length == 1 && params[0].isAssignableFrom(client.getClass())) {
                        constructor.setAccessible(true);
                        return constructor.newInstance(client);
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        return null;
    }

    private static double eyeHeight(Object entity) {
        return number(entity, 1.62D, new String[] {"standingEyeHeight", "eyeHeight"}, new String[] {"getStandingEyeHeight", "getEyeHeight"});
    }

    private static double velocity(Object entity, String axis) {
        if ("x".equals(axis)) {
            return number(entity, 0.0D, new String[] {"velocityX", "motionX", "field_70159_w"}, new String[0]);
        }
        if ("y".equals(axis)) {
            return number(entity, 0.0D, new String[] {"velocityY", "motionY", "field_70181_x"}, new String[0]);
        }
        return number(entity, 0.0D, new String[] {"velocityZ", "motionZ", "field_70179_y"}, new String[0]);
    }

    private static void scaleField(Object target, double factor, String... names) {
        double current = number(target, Double.NaN, names, new String[0]);
        if (!Double.isNaN(current)) {
            writeNumber(target, current * factor, names);
        }
    }

    private static double number(Object target, double fallback, String[] fields, String[] methods) {
        Object value = read(target, fields);
        if (!(value instanceof Number) && methods.length > 0) {
            value = call(target, methods);
        }
        return value instanceof Number ? ((Number) value).doubleValue() : fallback;
    }

    private static float wrapDegrees(float angle) {
        angle %= 360.0F;
        if (angle >= 180.0F) angle -= 360.0F;
        if (angle < -180.0F) angle += 360.0F;
        return angle;
    }

    private static Object read(Object target, String... names) {
        if (target == null) {
            return null;
        }
        for (String name : names) {
            Field field = findField(target.getClass(), name);
            if (field != null) {
                try {
                    field.setAccessible(true);
                    return field.get(target);
                } catch (Throwable ignored) {
                }
            }
        }
        return null;
    }

    private static void write(Object target, Object value, String... names) {
        if (target == null) {
            return;
        }
        for (String name : names) {
            Field field = findField(target.getClass(), name);
            if (field == null) {
                continue;
            }
            try {
                field.setAccessible(true);
                field.set(target, value);
                return;
            } catch (Throwable ignored) {
            }
        }
    }

    private static void writeNumber(Object target, double value, String... names) {
        if (target == null) {
            return;
        }
        for (String name : names) {
            Field field = findField(target.getClass(), name);
            if (field == null) {
                continue;
            }
            try {
                field.setAccessible(true);
                Class<?> type = field.getType();
                if (type == float.class || type == Float.class) {
                    field.set(target, Float.valueOf((float) value));
                } else if (type == int.class || type == Integer.class) {
                    field.set(target, Integer.valueOf((int) value));
                } else {
                    field.set(target, Double.valueOf(value));
                }
                return;
            } catch (Throwable ignored) {
            }
        }
    }

    private static Field findField(Class<?> type, String name) {
        Class<?> cursor = type;
        while (cursor != null) {
            try {
                return cursor.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
            }
            String owner;
            try {
                owner = resolver().unmapClassName("named", cursor.getName());
            } catch (Throwable ignored) {
                owner = cursor.getName();
            }
            for (Field field : cursor.getDeclaredFields()) {
                try {
                    String mapped = resolver().mapFieldName("named", owner, name, descriptor(field.getType()));
                    if (field.getName().equals(mapped)) {
                        return field;
                    }
                } catch (Throwable ignored) {
                }
            }
            cursor = cursor.getSuperclass();
        }
        return null;
    }

    private static Object call(Object target, String[] names, Object... args) {
        if (target == null) {
            return null;
        }
        for (String name : names) {
            Method method = findMethod(target.getClass(), name, args);
            if (method != null) {
                try {
                    method.setAccessible(true);
                    return method.invoke(target, args);
                } catch (Throwable ignored) {
                }
            }
        }
        return null;
    }

    private static Object callStatic(Class<?> type, String[] names, Object... args) {
        for (String name : names) {
            Method method = findMethod(type, name, args);
            if (method != null) {
                try {
                    method.setAccessible(true);
                    return method.invoke(null, args);
                } catch (Throwable ignored) {
                }
            }
        }
        return null;
    }

    private static boolean invoke(Object target, String[] names, Object... args) {
        if (target == null) {
            return false;
        }
        for (String name : names) {
            Method method = findMethod(target.getClass(), name, args);
            if (method == null) {
                continue;
            }
            try {
                method.setAccessible(true);
                method.invoke(target, args);
                return true;
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    private static Method findMethod(Class<?> type, String name, Object[] args) {
        Class<?> cursor = type;
        while (cursor != null) {
            String owner;
            try {
                owner = resolver().unmapClassName("named", cursor.getName());
            } catch (Throwable ignored) {
                owner = cursor.getName();
            }
            for (Method method : cursor.getDeclaredMethods()) {
                if (method.getParameterTypes().length != args.length ||
                        !compatible(method.getParameterTypes(), args)) {
                    continue;
                }
                if (method.getName().equals(name)) {
                    return method;
                }
                try {
                    String mapped = resolver().mapMethodName("named", owner, name, methodDescriptor(method));
                    if (method.getName().equals(mapped)) {
                        return method;
                    }
                } catch (Throwable ignored) {
                }
            }
            cursor = cursor.getSuperclass();
        }
        return null;
    }

    private static String methodDescriptor(Method method) {
        StringBuilder descriptor = new StringBuilder("(");
        for (Class<?> parameter : method.getParameterTypes()) {
            descriptor.append(descriptor(parameter));
        }
        return descriptor.append(')').append(descriptor(method.getReturnType())).toString();
    }

    private static String descriptor(Class<?> type) {
        if (type.isArray()) {
            return type.getName().replace('.', '/');
        }
        if (type.isPrimitive()) {
            if (type == void.class) return "V";
            if (type == boolean.class) return "Z";
            if (type == byte.class) return "B";
            if (type == char.class) return "C";
            if (type == short.class) return "S";
            if (type == int.class) return "I";
            if (type == long.class) return "J";
            if (type == float.class) return "F";
            return "D";
        }
        String name = type.getName();
        try {
            name = resolver().unmapClassName("named", name);
        } catch (Throwable ignored) {
        }
        return "L" + name.replace('.', '/') + ";";
    }

    private static MappingResolver resolver() {
        return FabricLoader.getInstance().getMappingResolver();
    }

    private static String mappedClassName(String namedClass) {
        try {
            return resolver().mapClassName("named", namedClass);
        } catch (Throwable ignored) {
            return namedClass;
        }
    }

    private static boolean compatible(Class<?>[] types, Object[] args) {
        for (int i = 0; i < types.length; i++) {
            if (args[i] == null) {
                if (types[i].isPrimitive()) return false;
                continue;
            }
            Class<?> expected = wrap(types[i]);
            if (!expected.isAssignableFrom(args[i].getClass())) {
                return false;
            }
        }
        return true;
    }

    private static Class<?> wrap(Class<?> type) {
        if (!type.isPrimitive()) return type;
        if (type == int.class) return Integer.class;
        if (type == float.class) return Float.class;
        if (type == double.class) return Double.class;
        if (type == boolean.class) return Boolean.class;
        if (type == long.class) return Long.class;
        if (type == short.class) return Short.class;
        if (type == byte.class) return Byte.class;
        if (type == char.class) return Character.class;
        return type;
    }
}
