package dev.zero.client.modules;

import dev.zero.client.module.Category;
import dev.zero.client.module.Module;
import dev.zero.client.util.GameAccess;

public final class AimAssistModule extends Module {
    public AimAssistModule() {
        super("aimassist", "AimAssist", Category.COMBAT, 60);
    }

    @Override
    public void onTick(Object client) {
        if (!GameAccess.inGame(client)) return;
        Object target = GameAccess.playerInView(client, 6.0D, 42.0D);
        if (target != null) {
            GameAccess.aimAt(client, target, 0.18F);
        }
    }
}
