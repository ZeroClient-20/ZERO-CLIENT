package dev.zero.client.module;

/** Base class shared by every toggleable module. */
public abstract class Module {
    private final String id;
    private final String name;
    private final Category category;
    private boolean enabled;
    private int keyCode;

    protected Module(String id, String name, Category category, int keyCode) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.keyCode = keyCode;
    }

    public final String getId() {
        return id;
    }

    public final String getName() {
        return name;
    }

    public final Category getCategory() {
        return category;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final int getKeyCode() {
        return keyCode;
    }

    public final void setKeyCode(int keyCode) {
        this.keyCode = keyCode;
    }

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final void setEnabled(boolean enabled) {
        if (this.enabled == enabled) {
            return;
        }
        this.enabled = enabled;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public abstract void onTick(Object minecraftClient);
}
