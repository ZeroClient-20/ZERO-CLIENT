package dev.zero.client.gui;

import dev.zero.client.module.Module;
import dev.zero.client.module.ModuleManager;
import dev.zero.client.util.GameAccess;
import dev.zero.client.util.ZeroRuntime;

import java.util.List;

/** HUD-based click GUI so the project does not depend on a third-party menu mod. */
public final class HudOverlay {
    private static boolean open;

    private HudOverlay() {
    }

    public static boolean isOpen() {
        return open;
    }

    public static void setOpen(boolean value) {
        open = value;
    }

    public static void click(int mouseX, int mouseY) {
        if (!open) return;
        int rowTop = 43;
        int rowHeight = 16;
        List<Module> modules = ModuleManager.getModules();
        for (int i = 0; i < modules.size(); i++) {
            int top = rowTop + i * rowHeight;
            if (mouseX >= 12 && mouseX <= 218 && mouseY >= top && mouseY < top + rowHeight) {
                modules.get(i).toggle();
                ModuleManager.save();
                return;
            }
        }
    }

    public static void render() {
        Object client = ZeroRuntime.getLastClient();
        if (client == null) {
            client = GameAccess.clientInstance();
        }
        if (client == null) return;

        if (open) {
            renderClickGui(client);
        }
        if (ModuleManager.get("esp") != null && ModuleManager.get("esp").isEnabled()) {
            renderEsp(client);
        }
    }

    private static void renderClickGui(Object client) {
        List<Module> modules = ModuleManager.getModules();
        int height = 46 + modules.size() * 16;
        GameAccess.drawRect(10, 10, 220, height, 0.035F, 0.045F, 0.075F, 0.92F);
        GameAccess.drawRect(10, 10, 220, 31, 0.32F, 0.08F, 0.78F, 0.96F);
        GameAccess.drawText(client, "ZERO CLIENT  |  1.8.9", 17, 17, 0xFFFFFFFF);
        GameAccess.drawText(client, "Right Shift: close  |  F1-F9: toggle", 17, 34, 0xFFB8B8C8);

        int y = 43;
        for (Module module : modules) {
            int color = module.isEnabled() ? 0xFF62E6A7 : 0xFFB8B8C8;
            if (module.isEnabled()) {
                GameAccess.drawRect(13, y - 1, 217, y + 14, 0.12F, 0.25F, 0.22F, 0.78F);
            }
            String state = module.isEnabled() ? "ON" : "OFF";
            GameAccess.drawText(client, module.getName(), 19, y + 2, color);
            GameAccess.drawText(client, state, 190, y + 2, color);
            y += 16;
        }
    }

    private static void renderEsp(Object client) {
        List<Object> players = GameAccess.players(client);
        if (players.isEmpty()) return;
        int width = GameAccess.scaledWidth(client);
        int x = Math.max(8, width - 158);
        int y = 12;
        int visible = Math.min(players.size(), 8);
        GameAccess.drawRect(x - 6, y - 5, x + 146, y + 18 + visible * 13, 0.02F, 0.025F, 0.04F, 0.72F);
        GameAccess.drawText(client, "ESP / PLAYERS", x, y, 0xFFB88CFF);
        y += 17;
        Object self = GameAccess.player(client);
        for (int i = 0; i < visible; i++) {
            Object player = players.get(i);
            int distance = (int) GameAccess.distance(self, player);
            String label = GameAccess.playerName(player) + "  " + distance + "m";
            GameAccess.drawText(client, label, x, y, 0xFFFFFFFF);
            y += 13;
        }
    }
}
