package dev.zero.client.modules;

import dev.zero.client.module.Category;
import dev.zero.client.module.Module;
import dev.zero.client.util.GameAccess;

public final class SprintModule extends Module {
    public SprintModule() {
        super("sprint", "Sprint", Category.MOVEMENT, 64);
    }

    @Override
    public void onTick(Object client) {
        if (!GameAccess.inGame(client)) return;
        Object player = GameAccess.player(client);
        if (GameAccess.moving(player) && !GameAccess.keyDown(42)) {
            GameAccess.setSprinting(player, true);
        }
    }
}
