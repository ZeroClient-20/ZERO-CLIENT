package dev.zero.client.modules;

import dev.zero.client.module.Category;
import dev.zero.client.module.Module;
import dev.zero.client.util.GameAccess;

public final class FlyModule extends Module {
    public FlyModule() {
        super("fly", "Fly", Category.MOVEMENT, 66);
    }

    @Override
    public void onTick(Object client) {
        if (!GameAccess.inGame(client)) return;
        Object player = GameAccess.player(client);
        GameAccess.enableFlight(player);
        if (GameAccess.keyDown(57)) {
            GameAccess.setVerticalVelocity(player, 0.42D);
        } else if (GameAccess.keyDown(42)) {
            GameAccess.setVerticalVelocity(player, -0.42D);
        } else {
            GameAccess.setVerticalVelocity(player, 0.0D);
        }
    }

    @Override
    public void onDisable() {
        // Vanilla/server permissions decide whether flight can remain enabled.
    }
}
