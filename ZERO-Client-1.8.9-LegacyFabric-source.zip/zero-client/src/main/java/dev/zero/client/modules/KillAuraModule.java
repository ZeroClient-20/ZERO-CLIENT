package dev.zero.client.modules;

import dev.zero.client.module.Category;
import dev.zero.client.module.Module;
import dev.zero.client.util.GameAccess;

public final class KillAuraModule extends Module {
    private int delay;

    public KillAuraModule() {
        super("killaura", "KillAura", Category.COMBAT, 59);
    }

    @Override
    public void onTick(Object client) {
        if (!GameAccess.inGame(client)) return;
        if (delay-- > 0) return;
        Object target = GameAccess.nearestPlayer(client, 3.35D);
        if (target == null) return;
        GameAccess.aimAt(client, target, 1.0F);
        GameAccess.attack(client, target);
        delay = 9;
    }
}
