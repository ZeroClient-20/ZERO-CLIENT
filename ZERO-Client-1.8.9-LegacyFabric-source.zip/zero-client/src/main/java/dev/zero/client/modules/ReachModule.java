package dev.zero.client.modules;

import dev.zero.client.module.Category;
import dev.zero.client.module.Module;
import dev.zero.client.util.GameAccess;

public final class ReachModule extends Module {
    private int delay;

    public ReachModule() {
        super("reach", "Reach", Category.COMBAT, 61);
    }

    @Override
    public void onTick(Object client) {
        if (!GameAccess.inGame(client) || !GameAccess.leftMouseDown()) return;
        if (delay-- > 0) return;
        Object target = GameAccess.playerInView(client, 5.2D, 5.0D);
        if (target != null) {
            GameAccess.attack(client, target);
            delay = 2;
        }
    }
}
