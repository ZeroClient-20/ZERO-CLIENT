package dev.zero.client.util;

import dev.zero.client.module.Module;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Properties;

/** Small dependency-free config store. */
public final class ConfigStore {
    private static final File FILE = new File("config/zero-client.properties");

    private ConfigStore() {
    }

    public static void load(List<Module> modules) {
        if (!FILE.isFile()) {
            return;
        }
        Properties properties = new Properties();
        try (FileInputStream input = new FileInputStream(FILE)) {
            properties.load(input);
            for (Module module : modules) {
                String enabled = properties.getProperty(module.getId() + ".enabled");
                String key = properties.getProperty(module.getId() + ".key");
                if (enabled != null) {
                    module.setEnabled(Boolean.parseBoolean(enabled));
                }
                if (key != null) {
                    module.setKeyCode(Integer.parseInt(key));
                }
            }
        } catch (Exception error) {
            System.err.println("[ZERO] Could not read config: " + error.getMessage());
        }
    }

    public static void save(List<Module> modules) {
        File parent = FILE.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            System.err.println("[ZERO] Could not create config directory.");
            return;
        }
        Properties properties = new Properties();
        for (Module module : modules) {
            properties.setProperty(module.getId() + ".enabled", Boolean.toString(module.isEnabled()));
            properties.setProperty(module.getId() + ".key", Integer.toString(module.getKeyCode()));
        }
        try (FileOutputStream output = new FileOutputStream(FILE)) {
            properties.store(output, "ZERO Client settings");
        } catch (Exception error) {
            System.err.println("[ZERO] Could not save config: " + error.getMessage());
        }
    }
}
