package dev.zero.client.modules;

import dev.zero.client.module.Category;
import dev.zero.client.module.Module;
import dev.zero.client.util.GameAccess;

public final class VelocityModule extends Module {
    private int lastHurtTime = -1;

    public VelocityModule() {
        super("velocity", "Velocity", Category.MOVEMENT, 63);
    }

    @Override
    public void onTick(Object client) {
        if (!GameAccess.inGame(client)) return;
        Object player = GameAccess.player(client);
        int hurtTime = GameAccess.hurtTime(player);
        if (hurtTime > 0 && hurtTime != lastHurtTime) {
            GameAccess.scaleVelocity(player, 0.25D, 0.35D);
        }
        lastHurtTime = hurtTime;
    }
}
