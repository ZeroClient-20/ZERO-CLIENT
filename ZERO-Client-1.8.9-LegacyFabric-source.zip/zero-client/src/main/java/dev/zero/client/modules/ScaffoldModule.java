package dev.zero.client.modules;

import dev.zero.client.module.Category;
import dev.zero.client.module.Module;
import dev.zero.client.util.GameAccess;

public final class ScaffoldModule extends Module {
    private int delay;

    public ScaffoldModule() {
        super("scaffold", "Scaffold", Category.MOVEMENT, 67);
    }

    @Override
    public void onTick(Object client) {
        if (!GameAccess.inGame(client)) return;
        Object player = GameAccess.player(client);
        if (!GameAccess.moving(player) || !GameAccess.onGround(player)) return;
        GameAccess.setPitch(player, 78.0F);
        if (delay-- <= 0) {
            GameAccess.vanillaRightClick(client);
            delay = 3;
        }
    }
}
