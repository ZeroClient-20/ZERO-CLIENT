package dev.zero.client.util;

import dev.zero.client.gui.HudOverlay;
import dev.zero.client.module.Module;
import dev.zero.client.module.ModuleManager;
import org.lwjgl.input.Mouse;

import java.util.HashSet;
import java.util.Set;

/** Client tick dispatcher and keybind handling. */
public final class ZeroRuntime {
    private static final int GUI_KEY = 54; // LWJGL2 KEY_RSHIFT
    private static final Set<Integer> HELD_KEYS = new HashSet<Integer>();
    private static boolean previousMouseDown;
    private static Object lastClient;

    private ZeroRuntime() {
    }

    public static void tick(Object client) {
        lastClient = client;
        handleKey(GUI_KEY, new Runnable() {
            @Override
            public void run() {
                HudOverlay.setOpen(!HudOverlay.isOpen());
            }
        });

        for (final Module module : ModuleManager.getModules()) {
            handleKey(module.getKeyCode(), new Runnable() {
                @Override
                public void run() {
                    module.toggle();
                    ModuleManager.save();
                }
            });
        }

        boolean mouseDown = false;
        try {
            mouseDown = Mouse.isButtonDown(0);
        } catch (Throwable ignored) {
        }
        if (mouseDown && !previousMouseDown && HudOverlay.isOpen()) {
            int x = GameAccess.mouseScaledX(GameAccess.scaledWidth(client));
            int y = GameAccess.mouseScaledY(GameAccess.scaledHeight(client));
            HudOverlay.click(x, y);
        }
        previousMouseDown = mouseDown;
        ModuleManager.tick(client);
    }

    public static Object getLastClient() {
        return lastClient;
    }

    private static void handleKey(int keyCode, Runnable action) {
        boolean down = GameAccess.keyDown(keyCode);
        boolean wasDown = HELD_KEYS.contains(Integer.valueOf(keyCode));
        if (down && !wasDown) {
            action.run();
            HELD_KEYS.add(Integer.valueOf(keyCode));
        } else if (!down && wasDown) {
            HELD_KEYS.remove(Integer.valueOf(keyCode));
        }
    }
}
