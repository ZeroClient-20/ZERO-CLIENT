package dev.zero.client.mixin;

import dev.zero.client.gui.HudOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws the custom menu and ESP list after the vanilla HUD. */
@Mixin(targets = "net.minecraft.client.gui.hud.InGameHud")
public abstract class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void zero$renderOverlay(CallbackInfo callbackInfo) {
        HudOverlay.render();
    }
}
