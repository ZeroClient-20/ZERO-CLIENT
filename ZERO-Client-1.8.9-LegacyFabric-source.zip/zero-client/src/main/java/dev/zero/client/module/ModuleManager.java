package dev.zero.client.module;

import dev.zero.client.modules.AimAssistModule;
import dev.zero.client.modules.AutoClickerModule;
import dev.zero.client.modules.ESPModule;
import dev.zero.client.modules.FlyModule;
import dev.zero.client.modules.KillAuraModule;
import dev.zero.client.modules.ReachModule;
import dev.zero.client.modules.ScaffoldModule;
import dev.zero.client.modules.SprintModule;
import dev.zero.client.modules.VelocityModule;
import dev.zero.client.util.ConfigStore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Central registry, tick dispatcher and config bridge. */
public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<Module>();
    private static boolean initialized;

    private ModuleManager() {
    }

    public static void initialize() {
        if (initialized) {
            return;
        }
        MODULES.add(new KillAuraModule());
        MODULES.add(new AimAssistModule());
        MODULES.add(new ReachModule());
        MODULES.add(new AutoClickerModule());
        MODULES.add(new VelocityModule());
        MODULES.add(new SprintModule());
        MODULES.add(new ESPModule());
        MODULES.add(new FlyModule());
        MODULES.add(new ScaffoldModule());
        ConfigStore.load(MODULES);
        initialized = true;
    }

    public static List<Module> getModules() {
        return Collections.unmodifiableList(MODULES);
    }

    public static Module get(String id) {
        for (Module module : MODULES) {
            if (module.getId().equalsIgnoreCase(id)) {
                return module;
            }
        }
        return null;
    }

    public static void tick(Object client) {
        for (Module module : MODULES) {
            if (module.isEnabled()) {
                try {
                    module.onTick(client);
                } catch (Throwable error) {
                    System.err.println("[ZERO] Module " + module.getName() + " failed: " + error.getMessage());
                }
            }
        }
    }

    public static void save() {
        ConfigStore.save(MODULES);
    }
}
