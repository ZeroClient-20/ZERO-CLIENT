package dev.zero.client.modules;

import dev.zero.client.module.Category;
import dev.zero.client.module.Module;

/** Rendering is performed by HudOverlay; this module is its visibility switch. */
public final class ESPModule extends Module {
    public ESPModule() {
        super("esp", "ESP", Category.RENDER, 65);
    }

    @Override
    public void onTick(Object client) {
        // HUD overlay reads this module's enabled state on every render.
    }
}
