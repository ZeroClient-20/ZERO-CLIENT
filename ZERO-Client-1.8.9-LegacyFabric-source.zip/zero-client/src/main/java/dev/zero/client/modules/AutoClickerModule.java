package dev.zero.client.modules;

import dev.zero.client.module.Category;
import dev.zero.client.module.Module;
import dev.zero.client.util.GameAccess;

public final class AutoClickerModule extends Module {
    private int delay;

    public AutoClickerModule() {
        super("autoclicker", "AutoClicker", Category.COMBAT, 62);
    }

    @Override
    public void onTick(Object client) {
        if (!GameAccess.inGame(client) || !GameAccess.leftMouseDown()) return;
        if (delay-- > 0) return;
        GameAccess.vanillaLeftClick(client);
        delay = 1;
    }
}
