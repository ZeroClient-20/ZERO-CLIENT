# ZERO Client — Minecraft Java 1.8.9 / Legacy Fabric

Client-side modular mod project. It is built against the Legacy Fabric 1.8.9 toolchain:

- Minecraft: `1.8.9`
- Legacy Yarn: `1.8.9+build.551`
- Fabric Loader: `0.16.10`
- Legacy Fabric API: `1.10.2+1.8.9`
- Java bytecode target: Java 8

## Included modules

| Module | Default key | Behavior in this source build |
|---|---:|---|
| KillAura | F1 | Selects a nearby player, aims at it and requests an attack through the client interaction controller. |
| AimAssist | F2 | Smoothly adjusts view angles toward a player within its cone. |
| Reach | F3 | Attempts an attack on a player aligned with the crosshair out to 5.2 blocks. Server-side reach validation still applies. |
| AutoClicker | F4 | Repeats the vanilla left-click action while the left mouse button is held. |
| Velocity | F5 | Scales client-side motion after damage. Server corrections can override it. |
| Sprint | F6 | Enables sprint while moving, unless the sneak key is held. |
| ESP | F7 | Displays a HUD player/name/distance panel. This build is a 2D HUD list, not 3D bounding-box rendering. |
| Fly | F8 | Toggles local flight ability flags and vertical movement. Servers can deny or correct flight. |
| Scaffold | F9 | Aims downward and repeats the vanilla right-click action while moving on the ground. Block placement depends on the current raycast, inventory and server rules. |
| Click GUI | Right Shift | Opens/closes a compact overlay; click a row or use F1–F9 to toggle modules. |

## Build

Use JDK 17 or newer to run Gradle 8.12, with Java 8 bytecode output. In the project folder:

```bash
gradle build
```

The remapped mod jar will be generated under `build/libs/`.

## Install

1. Install a **Legacy Fabric** profile for Minecraft 1.8.9 in the launcher.
2. Launch it once, then close the game.
3. Put the generated `zero-client-0.1.0.jar` into that profile's `mods` folder.
4. Start the Legacy Fabric 1.8.9 profile.
5. Press **Right Shift** for the menu. F1–F9 toggle individual modules.

Settings are written to `config/zero-client.properties`.

## Technical notes

This repository is the project source, not a prebuilt `.jar`. The environment used to assemble it had no outbound access to Maven/GitHub, so dependency resolution and an in-game launch could not be run here. The reflection adapter uses Fabric's `MappingResolver` to resolve named members at runtime, but the 1.8.9 client should still be smoke-tested after building. Minecraft 1.8.9 is an old, obfuscated target and client-side movement changes do not override server authority; modules that alter attacks, reach, flight or placement can be rejected by server-side checks.

The project intentionally does not contain anti-cheat bypass, server intrusion, account theft, or persistence outside Minecraft.
