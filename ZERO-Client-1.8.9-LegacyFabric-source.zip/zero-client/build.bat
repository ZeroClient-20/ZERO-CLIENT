@echo off
gradle build
if errorlevel 1 exit /b %errorlevel%
echo Build concluido. Confira build\libs\
